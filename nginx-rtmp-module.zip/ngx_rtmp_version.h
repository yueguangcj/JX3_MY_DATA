
/*
 * Copyright (C) Roman Arutyunyan
 */


#ifndef _NGX_RTMP_VERSION_H_INCLUDED_
#define _NGX_RTMP_VERSION_H_INCLUDED_


#define nginx_rtmp_version  1001004
#define NGINX_RTMP_VERSION  "1.1.4"


#endif /* _NGX_RTMP_VERSION_H_INCLUDED_ */
